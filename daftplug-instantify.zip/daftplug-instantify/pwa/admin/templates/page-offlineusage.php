<?php

if (!defined('ABSPATH')) exit;

?>
<div class="daftplugAdminPage_subpage -offlineusage -flex12" data-subpage="offlineusage">
    <div class="daftplugAdminPage_content -flex8">
        <div class="daftplugAdminSettings -flexAuto">
            <form name="daftplugAdminSettings_form" class="daftplugAdminSettings_form" data-nonce="<?php echo wp_create_nonce("{$this->optionName}_settings_nonce"); ?>" spellcheck="false" autocomplete="off">
                <fieldset class="daftplugAdminFieldset">
                    <h4 class="daftplugAdminFieldset_title"><?php esc_html_e('Offline Usage', $this->textDomain); ?></h4>
                    <p class="daftplugAdminFieldset_description"><?php esc_html_e('Offline usage adds offline support and reliable performance on your web app. This allows a visitor to load any previously viewed page while they are offline or on low connectivity network. The plugin also defines a special “Offline Page”, which allows you to customize a message and the experience if the app is offline and the page is not in the offline cache.', $this->textDomain); ?></p>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Select the special offline fallback page for your web application. This page will show up your users when they navigate your website without an Internet connection.', $this->textDomain); ?></p>
                        <label for="pwaOfflinePage" class="daftplugAdminField_label -flex4"><?php esc_html_e('Offline Page', $this->textDomain); ?></label>
                        <div class="daftplugAdminInputSelect -flexAuto">
                            <select name="pwaOfflinePage" id="pwaOfflinePage" class="daftplugAdminInputSelect_field" data-placeholder="<?php esc_html_e('Offline Page', $this->textDomain); ?>" autocomplete="off" required>
                                <?php foreach (get_pages() as $page) { ?>
                                <option value="<?php echo get_page_link($page->ID) ?>" <?php selected(daftplugInstantify::getSetting('pwaOfflinePage'), get_page_link($page->ID)) ?>><?php echo $page->post_title ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Select the pages that should be available for offline usage. This pages will be accessible when the user navigates your website without an internet connection.', $this->textDomain); ?></p>
                        <label for="pwaOfflineContent" class="daftplugAdminField_label -flex4"><?php esc_html_e('Offline Content', $this->textDomain); ?></label>
                        <div class="daftplugAdminInputSelect -flexAuto">
                            <select multiple name="pwaOfflineContent" id="pwaOfflineContent" class="daftplugAdminInputSelect_field" data-placeholder="<?php esc_html_e('Offline Content', $this->textDomain); ?>" autocomplete="off">
                                <?php foreach (get_pages() as $page) { ?>
                                <option value="<?php echo get_page_link($page->ID) ?>" <?php selected(true, in_array(get_page_link($page->ID), (array)daftplugInstantify::getSetting('pwaOfflineContent'))); ?>><?php echo $page->post_title ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Enable or disable live reconnecting notification for your users when they go offline or their connection interrupts on your website.', $this->textDomain); ?></p>
                        <label for="pwaOfflineNotification" class="daftplugAdminField_label -flex4"><?php esc_html_e('Offline Notification', $this->textDomain); ?></label>
                        <label class="daftplugAdminInputCheckbox -flexAuto">
                            <input type="checkbox" name="pwaOfflineNotification" id="pwaOfflineNotification" class="daftplugAdminInputCheckbox_field" <?php checked(daftplugInstantify::getSetting('pwaOfflineNotification'), 'on'); ?>>
                        </label>
                    </div>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Enable or disable offline form submission. If enabled, the forms data will be saved, then your website will automatically sync it once the user is online and submit pending forms in background using AJAX.', $this->textDomain); ?></p>
                        <label for="pwaOfflineForms" class="daftplugAdminField_label -flex4"><?php esc_html_e('Offline Forms', $this->textDomain); ?></label>
                        <label class="daftplugAdminInputCheckbox -flexAuto">
                            <input type="checkbox" name="pwaOfflineForms" id="pwaOfflineForms" class="daftplugAdminInputCheckbox_field" <?php checked(daftplugInstantify::getSetting('pwaOfflineForms'), 'on'); ?>>
                        </label>
                    </div>
                </fieldset>
                <div class="daftplugAdminSettings_submit">
                    <button type="submit" class="daftplugAdminButton -submit" data-submit="<?php esc_html_e('Save Settings', $this->textDomain); ?>" data-waiting="<?php esc_html_e('Waiting', $this->textDomain); ?>" data-submitted="<?php esc_html_e('Settings Saved', $this->textDomain); ?>" data-failed="<?php esc_html_e('Saving Failed', $this->textDomain); ?>"></button>
                </div>
            </form>
        </div>
    </div>
</div>