<?php

if (!defined('ABSPATH')) exit;

?>
<div class="daftplugAdminPage_subpage -accessibility -flex12" data-subpage="accessibility">
	<div class="daftplugAdminPage_content -flex8">
        <div class="daftplugAdminSettings -flexAuto">
            <form name="daftplugAdminSettings_form" class="daftplugAdminSettings_form" data-nonce="<?php echo wp_create_nonce("{$this->optionName}_settings_nonce"); ?>" spellcheck="false" autocomplete="off">
                <fieldset class="daftplugAdminFieldset">
                	<h4 class="daftplugAdminFieldset_title"><?php esc_html_e('Pull Down Navigation', $this->textDomain); ?></h4>
                    <p class="daftplugAdminFieldset_description"><?php esc_html_e('Pull down navigation touchscreen gesture allows your users to drag the screen and then release it, as a signal to the application to refresh contents or navigate your web app.', $this->textDomain); ?></p>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Enable or disable pull down navigation touchscreen gesture.', $this->textDomain); ?></p>
                        <label for="pwaPullDownNavigation" class="daftplugAdminField_label -flex4"><?php esc_html_e('Pull Down Navigation', $this->textDomain); ?></label>
                        <label class="daftplugAdminInputCheckbox -flexAuto">
                            <input type="checkbox" name="pwaPullDownNavigation" id="pwaPullDownNavigation" class="daftplugAdminInputCheckbox_field" <?php checked(daftplugInstantify::getSetting('pwaPullDownNavigation'), 'on'); ?>>
                        </label>
                    </div>
                    <div class="daftplugAdminField -pwaPullDownNavigationDependentDisableD">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Select the background color of pull down navigation touchscreen gesture.', $this->textDomain); ?></p>
                        <label for="pwaPullDownNavigationBgColor" class="daftplugAdminField_label -flex4"><?php esc_html_e('Background Color', $this->textDomain); ?></label>
                        <div class="daftplugAdminInputColor -flexAuto">
                            <input type="text" name="pwaPullDownNavigationBgColor" id="pwaPullDownNavigationBgColor" class="daftplugAdminInputColor_field" value="<?php echo daftplugInstantify::getSetting('pwaPullDownNavigationBgColor'); ?>" data-placeholder="<?php esc_html_e('Background Color', $this->textDomain); ?>" required>
                        </div>
                    </div>
                </fieldset>
                <fieldset class="daftplugAdminFieldset">
                	<h4 class="daftplugAdminFieldset_title"><?php esc_html_e('Swipe Navigation', $this->textDomain); ?></h4>
                    <p class="daftplugAdminFieldset_description"><?php esc_html_e('Swipe Navigation allows your users to execute web browser\'s "Back" and "Next" actions by simple swiping on the screen anywhere on the website. Swiping left will result in going back and swiping right will result in going next.', $this->textDomain); ?></p>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Enable or disable swipe navigation touchscreen gesture.', $this->textDomain); ?></p>
                        <label for="pwaSwipeNavigation" class="daftplugAdminField_label -flex4"><?php esc_html_e('Swipe Navigation', $this->textDomain); ?></label>
                        <label class="daftplugAdminInputCheckbox -flexAuto">
                            <input type="checkbox" name="pwaSwipeNavigation" id="pwaSwipeNavigation" class="daftplugAdminInputCheckbox_field" <?php checked(daftplugInstantify::getSetting('pwaSwipeNavigation'), 'on'); ?>>
                        </label>
                    </div>
                </fieldset>
                <fieldset class="daftplugAdminFieldset">
                	<h4 class="daftplugAdminFieldset_title"><?php esc_html_e('Shake To Refresh', $this->textDomain); ?></h4>
                    <p class="daftplugAdminFieldset_description"><?php esc_html_e('Shake to refresh gesture brings amazing UX experience to your users by simply shaking phone as a signal to your web application to refresh the contents of the screen.', $this->textDomain); ?></p>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Enable or disable shake to refresh gesture.', $this->textDomain); ?></p>
                        <label for="pwaShakeToRefresh" class="daftplugAdminField_label -flex4"><?php esc_html_e('Shake To Refresh', $this->textDomain); ?></label>
                        <label class="daftplugAdminInputCheckbox -flexAuto">
                            <input type="checkbox" name="pwaShakeToRefresh" id="pwaShakeToRefresh" class="daftplugAdminInputCheckbox_field" <?php checked(daftplugInstantify::getSetting('pwaShakeToRefresh'), 'on'); ?>>
                        </label>
                    </div>
                </fieldset>
                <fieldset class="daftplugAdminFieldset">
                	<h4 class="daftplugAdminFieldset_title"><?php esc_html_e('Vibration', $this->textDomain); ?></h4>
                    <p class="daftplugAdminFieldset_description"><?php esc_html_e('Vibration feature creates vibes on tapping for mobile users. That can help mobile users recognize when they are tapping and clicking on your website.', $this->textDomain); ?></p>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Enable or disable vibration support for your web app.', $this->textDomain); ?></p>
                        <label for="pwaVibration" class="daftplugAdminField_label -flex4"><?php esc_html_e('Vibration', $this->textDomain); ?></label>
                        <label class="daftplugAdminInputCheckbox -flexAuto">
                            <input type="checkbox" name="pwaVibration" id="pwaVibration" class="daftplugAdminInputCheckbox_field" <?php checked(daftplugInstantify::getSetting('pwaVibration'), 'on'); ?>>
                        </label>
                    </div>
                </fieldset>
                <fieldset class="daftplugAdminFieldset">
                	<h4 class="daftplugAdminFieldset_title"><?php esc_html_e('Preloader', $this->textDomain); ?></h4>
                    <p class="daftplugAdminFieldset_description"><?php esc_html_e('Preloader feature adds a nice page loader with a bouncing site icon on your website\'s background color. Loader appears at the start of page load and disappears after it is fully loaded.', $this->textDomain); ?></p>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Enable or disable preloader for your web app.', $this->textDomain); ?></p>
                        <label for="pwaPreloader" class="daftplugAdminField_label -flex4"><?php esc_html_e('Preloader', $this->textDomain); ?></label>
                        <label class="daftplugAdminInputCheckbox -flexAuto">
                            <input type="checkbox" name="pwaPreloader" id="pwaPreloader" class="daftplugAdminInputCheckbox_field" <?php checked(daftplugInstantify::getSetting('pwaPreloader'), 'on'); ?>>
                        </label>
                    </div>
                </fieldset>
                <fieldset class="daftplugAdminFieldset">
                	<h4 class="daftplugAdminFieldset_title"><?php esc_html_e('Toast Messages', $this->textDomain); ?></h4>
                    <p class="daftplugAdminFieldset_description"><?php esc_html_e('Toast Messages provide simple feedback about an operation in a small popup. It only fills the amount of space required for the message and the current activity remains visible and interactive. Toasts automatically disappear after a timeout.', $this->textDomain); ?></p>
                    <div class="daftplugAdminField">
                        <p class="daftplugAdminField_description"><?php esc_html_e('Enable or disable toast messages for your web app.', $this->textDomain); ?></p>
                        <label for="pwaToastMessages" class="daftplugAdminField_label -flex4"><?php esc_html_e('Toast Messages', $this->textDomain); ?></label>
                        <label class="daftplugAdminInputCheckbox -flexAuto">
                            <input type="checkbox" name="pwaToastMessages" id="pwaToastMessages" class="daftplugAdminInputCheckbox_field" <?php checked(daftplugInstantify::getSetting('pwaToastMessages'), 'on'); ?>>
                        </label>
                    </div>
                </fieldset>
                <div class="daftplugAdminSettings_submit">
                    <button type="submit" class="daftplugAdminButton -submit" data-submit="<?php esc_html_e('Save Settings', $this->textDomain); ?>" data-waiting="<?php esc_html_e('Waiting', $this->textDomain); ?>" data-submitted="<?php esc_html_e('Settings Saved', $this->textDomain); ?>" data-failed="<?php esc_html_e('Saving Failed', $this->textDomain); ?>"></button>
                </div>
            </form>
        </div>
    </div>
</div>