<?php

if (!defined('ABSPATH')) exit;

if (!class_exists('daftplugInstantifyPwaAdminPushnotifications')) {
    class daftplugInstantifyPwaAdminPushnotifications {
    	public $name;
        public $description;
        public $slug;
        public $version;
        public $textDomain;
        public $optionName;

        public $pluginFile;
        public $pluginBasename;

        public $settings;
        public $firebaseCreds;
        public $subscribedDevices;

    	public function __construct($config) {
    		$this->name = $config['name'];
            $this->description = $config['description'];
            $this->slug = $config['slug'];
            $this->version = $config['version'];
            $this->textDomain = $config['text_domain'];
            $this->optionName = $config['option_name'];

            $this->pluginFile = $config['plugin_file'];
            $this->pluginBasename = $config['plugin_basename'];

            $this->settings = $config['settings'];
            $this->firebaseCreds = get_option("{$this->optionName}_firebase_creds", true);
            $this->subscribedDevices = get_option("{$this->optionName}_subscribed_devices", true);

            add_action("wp_ajax_{$this->optionName}_set_firebase_creds", array($this, 'setFirebaseCreds'));

            if ($this->firebaseCreds['pwaPush'] == 'on') {
            	add_action("wp_ajax_{$this->optionName}_remove_firebase_creds", array($this, 'removeFirebaseCreds'));
            	add_action("wp_ajax_{$this->optionName}_send_push", array($this, 'doModalPush'));
        	}
    	}

        public function setFirebaseCreds() {
            $nonce = $_POST['nonce'];
            $serverKey = trim($_POST['serverKey']);
            $senderId = trim($_POST['senderId']);

            if (wp_verify_nonce($nonce, "{$this->optionName}_firebase_creds_nonce")) {
                update_option("{$this->optionName}_firebase_creds", array('pwaServerKey' => $serverKey, 'pwaSenderId' => $senderId, 'pwaPush' => 'on'));
                wp_die('1');
            } else {
                wp_die('0');
            }
        }

        public function removeFirebaseCreds() {
            $nonce = $_POST['nonce'];

            if (wp_verify_nonce($nonce, "{$this->optionName}_remove_firebase_creds_nonce")) {
                update_option("{$this->optionName}_firebase_creds", array('pwaServerKey' => '', 'pwaSenderId' => '', 'pwaPush' => 'off'));
                wp_die('1');
            } else {
                wp_die('0');
            }
        }

        public function doModalPush() {
            $imageId = $_POST['pushImage'];

            if (get_post_type($imageId) == 'attachment') {
                $image = daftplugInstantifyPwa::resizeImage($imageId, 500, 500, true);
                if ($image) {
                    $imageUrl = $image[0];
                }
            }

            $data = array(
                'title' => sanitize_text_field($_POST['pushTitle']),
                'body' => sanitize_text_field($_POST['pushBody']),
                'redirect' => esc_url_raw($_POST['pushUrl']),
                'imageUrl' => esc_url_raw($imageUrl),
                'subscriptionId' => sanitize_text_field($_POST['subscriptionId']),
            );

            $sendPushNotification = $this->sendPushNotification($data);

            if ($sendPushNotification == '1' && $_POST['pushMeta']) {
                update_post_meta($_POST['pushMeta'], "{$this->optionName}_pushmeta", 'done');
            }

            if ($sendPushNotification == '1' && wp_verify_nonce($_POST['nonce'], "{$this->optionName}_send_push_nonce")) {
                wp_die('1');
            } else {
                wp_die('0');
            }
        }

        public function sendPushNotification($data) {
            $subscriptionId = $data['subscriptionId'];
            unset($data['subscriptionId']);

            if ($subscriptionId == 'all') {
            	$subscriptionId = array();
                foreach ($this->subscribedDevices as $subscribedDevice) {
                    $subscriptionId[] = $subscribedDevice['subscriptionId'];
                }
            } else {
                $subscriptionId = array($subscriptionId);
            }

            $badge = daftplugInstantify::getSetting('pwaNotificationBarIcon');

            if (get_post_type($badge) == 'attachment') {
                $badgeImg = daftplugInstantifyPwa::resizeImage($badge, 96, 96, true);
                if ($badgeImg) {
                    $badgeUrl = $badgeImg[0];
                }
            } else {
                $badgeUrl = '';
            }

            $data['icon'] = $data['imageUrl'];

            $data = shortcode_atts(array(
                'title' => 'Notification Title',
                'badge' => $badgeUrl,
                'body' => '',
                'icon' => '',
                'image' => '',
                'redirect' => '',
            ), $data);

            $saveData = daftplugInstantifyPwa::putContent(trailingslashit(WP_CONTENT_DIR) . '/data-push.json', json_encode($data));

            if (!$saveData) {
                wp_die('0');
            }

            $fields = array(
                'registration_ids' => $subscriptionId,
                'data' => array(
                    'message' => $data,
                ),
            );
        
            $headers = array(
                'Authorization: key=' . $this->firebaseCreds['pwaServerKey'],
                'Content-Type: application/json',
            );

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);

            $result = json_decode($result, true);

            $success = array();
            $failed = array();

            if (daftplugInstantify::getSetting('pwaRemoveIfFail') == 'on') {
                foreach ($result['results'] as $key => $answer) {
                    if (array_key_exists('error', $answer)) {
                        $failed[] = $devices[$key];
                    } else {
                        $success[] = $devices[$key];
                    }
                }

                if (!empty($failed)) {
                    $oldDevices = $this->subscribedDevices;
                    foreach ($failedDevices as $failedDevice) {
                        unset($oldDevices[sanitize_key($failedDevice)]);
                    }
                    update_option("{$this->optionName}_subscribed_devices", $oldDevices);
                }
            }

            wp_die('1');
        }
    }
}