const data = self.registration.scope + 'wp-content/data-push.json';

self.addEventListener('push', event => {
	event.waitUntil(
		registration.pushManager.getSubscription()
			.then(function(subscription) {
				return fetch(data)
					.then(function(response) {
						return response.json()
							.then(function(data) {
								return self.registration.showNotification(data.title, {
									body: data.body,
									badge: data.badge,
									icon: data.icon,
									image: data.image
								});
							})
					})
			})
	);
});

self.addEventListener('notificationclick', event => {
    event.notification.close();
	event.waitUntil(
		fetch(data)
			.then(function(response) {
				return response.json()
					.then(function(data) {
						if (data.redirect !== '') {
							clients.openWindow(data.redirect);
						}
					})
			})
	);
});