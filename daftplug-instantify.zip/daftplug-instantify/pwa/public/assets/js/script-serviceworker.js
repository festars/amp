'use strict';

const cacheName = '{{cacheName}}';
const cachedPages = {{cachedPages}};
const offlinePage = '{{offlinePage}}';

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(cacheName)
        .then(cache => {
            return cache.addAll(cachedPages).then(function() {
                return cache.add(offlinePage);
            });
        })
        .then(function() {
            return self.skipWaiting();
        })
    );
});

self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys()
        .then(keys => {
            return Promise.all(
                keys.map(key => {
                    if (key !== cacheName) {
                        return caches.delete(key);
                    }
                })
            );
        })
    );
});

self.addEventListener('fetch', event => {
    let request = event.request;
    let url = new URL(request.url);

    // Dnly deal with requests on the same domain.
    if (url.origin !== location.origin) {
        return;
    }

    // Don't do anything if wp stuff
    if (request.url.match(/wp-admin/) || request.url.match(/preview=true/)) {
        return;
    }

    // If non-GET request, try the network first, fall back to the offline page
    if (request.method !== 'GET') {
        event.respondWith(
            fetch(request)
            .catch(error => {
                return caches.match(offlinePage);
            })
        );
        return;
    }

    // Try the network first (and update cache), fall back to the cache, finally the offline page
    event.respondWith(
        fetch(request)
        .then(response => {
            addToCache(request);
            return response;
        })
        .catch(error => {
            return caches.match(request)
                .then(response => {
                    return response || caches.match(offlinePage);
                });
        })
    );

    const addToCache = function(request) {
        return caches.open(cacheName)
            .then(cache => {
                return fetch(request)
                    .then(response => {
                        return cache.put(request, response);
                    });
            });
    };
});