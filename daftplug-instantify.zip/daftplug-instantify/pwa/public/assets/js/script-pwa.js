(function($) {
'use strict';
    jQuery(function() {
        var daftplugPublic = jQuery('.daftplugPublic');
        var optionName = daftplugPublic.attr('data-daftplug-plugin');
        var objectName = window[optionName + '_public_js_vars'];
        var client = new ClientJS();
        var isMobilePad = client.isMobile() || client.isIpad();
        var pushSubscribeButton = daftplugPublic.find('.daftplugPublicSubscribeButton');
        var isAndroidChrome = client.isMobileAndroid() && client.isChrome();
        var isAndroidFirefox = client.isMobileAndroid() && client.isFirefox();
        var isIosSafari = client.isMobileIOS() && client.isSafari();
        var isAndroidStandalone = window.matchMedia('(display-mode: standalone)').matches;
        var isIosStandalone = ('standalone' in window.navigator) && window.navigator.standalone;
        var isChromeOverlayShown = getCookie('chromeOverlay');
        var isChrome2OverlayShown = getCookie('chrome2Overlay');
        var isFirefoxOverlayShown = getCookie('firefoxOverlay');
        var isSafariOverlayShown = getCookie('safariOverlay');
        var isHeaderOverlayShown = getCookie('headerOverlay');
        var isMenuOverlayShown = getCookie('menuOverlay');
        var isCheckoutOverlayShown = getCookie('checkoutOverlay');
        var chromeOverlay = daftplugPublic.find('.daftplugPublicOverlay.-chrome');
        var chrome2Overlay = daftplugPublic.find('.daftplugPublicOverlay.-chrome2');
        var firefoxOverlay = daftplugPublic.find('.daftplugPublicOverlay.-firefox');
        var safariOverlay = daftplugPublic.find('.daftplugPublicOverlay.-safari');
        var headerOverlay = daftplugPublic.find('.daftplugPublicHeaderOverlay');
        var menuOverlay = daftplugPublic.find('.daftplugPublicMenuOverlay');
        var checkoutOverlay = daftplugPublic.find('.daftplugPublicCheckoutOverlay');
        var installButton = daftplugPublic.find('.daftplugPublicInstallButton');

        // Set cookie
        function setCookie(name, value, days) {
            var expires = '';
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = '; expires=' + date.toUTCString();
            }
            document.cookie = name + '=' + (value || '') + expires + '; path=/';
        }
        
        // Get cookie
        function getCookie(name) {
            var nameEQ = name + '=';
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
            }
            return null;
        }

        // Register push device
        function registerPushDevice() {
            if (objectName.settings.pwaSubscribeButton == 'on') {
                pushSubscribeButton.removeClass('-on').removeClass('-off').addClass('-loading');
            }
            navigator.serviceWorker.ready.then(function(registration) {
                registration.pushManager.subscribe({
                    userVisibleOnly: true
                }).then(function(subscription) {
                    var subscriptionId = subscription.endpoint.split('fcm/send/')[1];
                    handleSubscriptionId(subscriptionId, 'add');
                    if (objectName.settings.pwaSubscribeButton == 'on') {
                        pushSubscribeButton.removeClass('-loading').removeClass('-on').addClass('-off');
                    }
                    jQuery.toast({
                        title: 'Notifications are turned on!',
                        duration: 2500,
                        position: 'bottom',
                    });
                }).catch(function() {
                    if (objectName.settings.pwaSubscribeButton == 'on') {
                        pushSubscribeButton.removeClass('-loading').removeClass('-off').addClass('-on');
                    }
                    jQuery.toast({
                        title: 'Notifications are blocked!',
                        duration: 2500,
                        position: 'bottom',
                    });
                });
            });
        }

        // Deregister push device
        function deregisterPushDevice() {
            if (objectName.settings.pwaSubscribeButton == 'on') {
                pushSubscribeButton.removeClass('-on').removeClass('-off').addClass('-loading');
            }
            navigator.serviceWorker.ready.then(function(registration) {
                registration.pushManager.getSubscription().then(function(subscription) {
                    if (!subscription) {
                        return;
                    }
                    subscription.unsubscribe().then(function() {
                        var subscriptionId = subscription.endpoint.split('fcm/send/')[1];
                        handleSubscriptionId(subscriptionId, 'remove');
                        if (objectName.settings.pwaSubscribeButton == 'on') {
                            pushSubscribeButton.removeClass('-loading').removeClass('-off').addClass('-on');
                        }
                        jQuery.toast({
                            title: 'Notifications are turned off!',
                            duration: 2500,
                            position: 'bottom',
                        });
                    }).catch(function() {
                        if (objectName.settings.pwaSubscribeButton == 'on') {
                            pushSubscribeButton.removeClass('-loading').removeClass('-on').addClass('-off');
                        }
                        jQuery.toast({
                            title: 'Notifications could not be turned off!',
                            duration: 2500,
                            position: 'bottom',
                        });
                    });
                });
            });
        }

        // Handle subscription ID
        function handleSubscriptionId(subscriptionId, handle) {
            var action = optionName + '_handle_subscription_id';
            var handle = handle;
            var subscriptionId = subscriptionId;
            var deviceInfo = client.getBrowser() + ' ' + client.getBrowserMajorVersion() + ' on ' + client.getOS() + ' ' + client.getOSVersion();

            jQuery.ajax({
                url: objectName.ajaxUrl,
                dataType: 'json',
                type: 'POST',
                data: {
                    action: action,
                    handle: handle,
                    subscriptionId: subscriptionId,
                    deviceInfo: deviceInfo
                },
                beforeSend: function() {

                },
                success: function(response, textStatus, jqXhr) {

                },
                complete: function() {

                },
                error: function(jqXhr, textStatus, errorThrown) {

                }
            });
        }

        // Handle push
        if ('serviceWorker' in navigator && 'PushManager' in window) {
            navigator.serviceWorker.ready.then(function(registration) {
                // Handle ask on load
                if (objectName.settings.pwaAskOnLoad == 'on') {
                    registration.pushManager.getSubscription().then(function(subscription) {
                        if (subscription) {
                            if (objectName.settings.pwaSubscribeButton == 'on') {
                                pushSubscribeButton.removeClass('-loading').removeClass('-off').addClass('-on');
                            }
                        } else {
                            registerPushDevice();
                        }
                    });
                }

                // Handle subscribe button
                if (objectName.settings.pwaSubscribeButton == 'on') {
                    pushSubscribeButton.css('display', 'flex');
                    registration.pushManager.getSubscription().then(function(subscription) {
                        if (subscription) {
                            pushSubscribeButton.removeClass('-loading').removeClass('-on').addClass('-off');
                        } else {
                            pushSubscribeButton.removeClass('-loading').removeClass('-off').addClass('-on');
                        }
                    });

                    daftplugPublic.on('click', '.daftplugPublicSubscribeButton', function(e) {
                        registration.pushManager.getSubscription().then(function(subscription) {
                            if (subscription) {
                                deregisterPushDevice();
                            } else {
                                registerPushDevice();
                            }
                        });
                    });
                }
            });
        }

        // Handle offline forms
        if (objectName.settings.pwaOfflineForms == 'on') {
            Array.from(document.querySelectorAll('form')).forEach(form => {
                new OfflineForm(form);
            })
        };

        // Handle preloader
        if (objectName.settings.pwaPreloader == 'on') {
        	jQuery('body, html').css('overflow', 'hidden');
            jQuery(window).load(function(e) {
                daftplugPublic.find('.daftplugPublicPreloader').fadeOut('slow', function(e) {
                	jQuery('body, html').css('overflow', 'auto');
                });
            });
        }

        // Handle mobile staff
        if (isMobilePad) {
            // Handle pull down navigation
            if (objectName.settings.pwaPullDownNavigation == 'on') {
                PullToNavigate();
                jQuery('#daftplugPublicPullDownNavigation').css('background', objectName.settings.pwaPullDownNavigationBgColor);
            }

            // Handle swipe navigation
            if (objectName.settings.pwaSwipeNavigation == 'on') {
                jQuery('body').attr('data-xthreshold', '111').swipeleft(function() { 
                    window.history.back();
                    jQuery.toast({
                        title: 'Moved Back',
                        duration: 3000,
                        position: 'bottom',
                    });
                }).swiperight(function() { 
                    window.history.forward(); 
                    jQuery.toast({
                        title: 'Moved Forward',
                        duration: 3000,
                        position: 'bottom',
                    });
                });
            }

            // Handle shake to refresh
            if (objectName.settings.pwaShakeToRefresh == 'on') {
                var shakeEvent = new Shake({threshold: 15});
                shakeEvent.start();
                window.addEventListener('shake', function() {
                    location.reload();
                }, false);
            }

            // Handle vibration
            if (objectName.settings.pwaVibration == 'on') {
                jQuery('body').vibrate();
            }

        	// Handle installation overlays
	        if (objectName.settings.pwaOverlays == 'on') {
		        // Handle Chrome fullscreen installation overlays
		        if (objectName.settings.pwaOverlaysBrowsers.includes('chrome') && objectName.settings.pwaOverlaysTypes.includes('fullscreen') && isAndroidChrome && isAndroidStandalone == false && isChromeOverlayShown == null && isChrome2OverlayShown == null && chromeOverlay.length && chrome2Overlay.length) {
		            navigator.serviceWorker.getRegistrations().then(registrations => {
		                if (!registrations.length == 0) {
		                    var installPromptEvent = void 0;
		                    window.addEventListener('beforeinstallprompt', function(event) {
		                        event.preventDefault();
		                        installPromptEvent = event;

		                        setTimeout(function() {
		                            chromeOverlay.show();
		                        }, 5000);

		                        chromeOverlay.on('click', '.daftplugPublicOverlay_button', function(e) {
		                            chromeOverlay.hide('fast', function(e) {
		                                setCookie('chromeOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                            });

		                            installPromptEvent.prompt();
		                            installPromptEvent.userChoice.then(function(choice) {
		                                if (choice.outcome === 'accepted') {
		                                    // User accepted the A2HS prompt
		                                } else {
		                                    chromeOverlay.show();
		                                }
		                                installPromptEvent = null;
		                            });
		                        });
		                    });
		                } else {
		                    setTimeout(function() {
		                        chrome2Overlay.show();
		                    }, 5000);
		                }
		            });

		            chromeOverlay.on('click', '.daftplugPublicOverlay_close', function(e) {
		                chromeOverlay.hide('fast', function(e) {
		                    setCookie('chromeOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                });
		            });

		            chrome2Overlay.on('click', '.daftplugPublicOverlay_close', function(e) {
		                chrome2Overlay.hide('fast', function(e) {
		                    setCookie('chrome2Overlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                });
		            });
		        }

		        // Handle Firefox fullscreen installation overlay
		        if (objectName.settings.pwaOverlaysBrowsers.includes('firefox') && objectName.settings.pwaOverlaysTypes.includes('fullscreen') && isAndroidFirefox && isAndroidStandalone == false && isFirefoxOverlayShown == null && firefoxOverlay.length) {
		            setTimeout(function() {
		                firefoxOverlay.show();
		            }, 5000);

		            firefoxOverlay.on('click', '.daftplugPublicOverlay_close', function(e) {
		                firefoxOverlay.hide('fast', function(e) {
		                    setCookie('firefoxOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                });
		            });
		        }

		        // Handle Safari fullscreen installation overlay
		        if (objectName.settings.pwaOverlaysBrowsers.includes('safari') && objectName.settings.pwaOverlaysTypes.includes('fullscreen') && isIosSafari && isIosStandalone == false && isSafariOverlayShown == null && safariOverlay.length) {
		            setTimeout(function() {
		                safariOverlay.show();
		            }, 5000);

		            safariOverlay.on('click', '.daftplugPublicOverlay_close', function(e) {
		                safariOverlay.hide('fast', function(e) {
		                    setCookie('safariOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                });
		            });
		        }

		        // Handle header installation overlay
		        if (objectName.settings.pwaOverlaysTypes.includes('header') && isAndroidStandalone == false && isIosStandalone == false && isHeaderOverlayShown == null && headerOverlay.length) {
	                if (objectName.settings.pwaOverlaysBrowsers.includes('chrome') && isAndroidChrome && chrome2Overlay.length) {
			            navigator.serviceWorker.getRegistrations().then(registrations => {
			                if (!registrations.length == 0) {
			                    var installPromptEvent = void 0;
			                    window.addEventListener('beforeinstallprompt', function(event) {
			                        event.preventDefault();
			                        installPromptEvent = event;

			                        setTimeout(function() {
			                            headerOverlay.css('display', 'flex');
			                        }, 5000);

			                        headerOverlay.on('click', '.daftplugPublicHeaderOverlay_button', function(e) {
			                            headerOverlay.hide('fast', function(e) {
			                                setCookie('headerOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
			                            });

			                            installPromptEvent.prompt();
			                            installPromptEvent.userChoice.then(function(choice) {
			                                if (choice.outcome === 'accepted') {
			                                    // User accepted the A2HS prompt
			                                } else {
			                                    headerOverlay.css('display', 'flex');
			                                }
			                                installPromptEvent = null;
			                            });
			                        });
			                    });
			                } else {
					            setTimeout(function() {
					                headerOverlay.css('display', 'flex');
					            }, 5000);

								headerOverlay.on('click', '.daftplugPublicHeaderOverlay_button', function(e) {
		                            headerOverlay.hide('fast', function(e) {
		                                setCookie('headerOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                            });
				                	chrome2Overlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
						                chrome2Overlay.hide('fast');
						            });
			                    });
			                }
			            });
	                } else if (objectName.settings.pwaOverlaysBrowsers.includes('firefox') && isAndroidFirefox && firefoxOverlay.length) {
			            setTimeout(function() {
			                headerOverlay.css('display', 'flex');
			            }, 5000);

						headerOverlay.on('click', '.daftplugPublicHeaderOverlay_button', function(e) {
	                        headerOverlay.hide('fast', function(e) {
	                            setCookie('headerOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
	                        });
		                	firefoxOverlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
				                firefoxOverlay.hide('fast');
				            });
	                    });
	                } else if (objectName.settings.pwaOverlaysBrowsers.includes('safari') && isIosSafari && safariOverlay.length) {
			            setTimeout(function() {
			                headerOverlay.css('display', 'flex');
			            }, 5000);

						headerOverlay.on('click', '.daftplugPublicHeaderOverlay_button', function(e) {
	                        headerOverlay.hide('fast', function(e) {
	                            setCookie('headerOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
	                        });
		                	safariOverlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
				                safariOverlay.hide('fast');
				            });
	                    });
	                }

		            headerOverlay.on('click', '.daftplugPublicHeaderOverlay_dismiss', function(e) {
		                headerOverlay.hide('fast', function(e) {
		                    setCookie('headerOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                });
		            });
		        }

		        // Handle menu installation overlay
		        if (objectName.settings.pwaOverlaysTypes.includes('menu') && isAndroidStandalone == false && isIosStandalone == false && isMenuOverlayShown == null && menuOverlay.length) {
	                if (objectName.settings.pwaOverlaysBrowsers.includes('chrome') && isAndroidChrome && chrome2Overlay.length) {
			            navigator.serviceWorker.getRegistrations().then(registrations => {
			                if (!registrations.length == 0) {
			                    var installPromptEvent = void 0;
			                    window.addEventListener('beforeinstallprompt', function(event) {
			                        event.preventDefault();
			                        installPromptEvent = event;
			                        menuOverlay.css('display', 'flex').on('click', '.daftplugPublicMenuOverlay_install', function(e) {
			                            menuOverlay.hide('fast', function(e) {
			                                setCookie('menuOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
			                            });

			                            installPromptEvent.prompt();
			                            installPromptEvent.userChoice.then(function(choice) {
			                                if (choice.outcome === 'accepted') {
			                                    // User accepted the A2HS prompt
			                                } else {
			                                    menuOverlay.css('display', 'flex');
			                                }
			                                installPromptEvent = null;
			                            });
			                        });
			                    });
			                } else {
					            menuOverlay.css('display', 'flex').on('click', '.daftplugPublicMenuOverlay_install', function(e) {
		                            menuOverlay.hide('fast', function(e) {
		                                setCookie('menuOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                            });
				                	chrome2Overlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
						                chrome2Overlay.hide('fast');
						            });
			                    });
			                }
			            });
	                } else if (objectName.settings.pwaOverlaysBrowsers.includes('firefox') && isAndroidFirefox && firefoxOverlay.length) {
					    menuOverlay.css('display', 'flex').on('click', '.daftplugPublicMenuOverlay_install', function(e) {
	                        menuOverlay.hide('fast', function(e) {
	                            setCookie('menuOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
	                        });
		                	firefoxOverlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
				                firefoxOverlay.hide('fast');
				            });
	                    });
	                } else if (objectName.settings.pwaOverlaysBrowsers.includes('safari') && isIosSafari && safariOverlay.length) {
						menuOverlay.css('display', 'flex').on('click', '.daftplugPublicMenuOverlay_install', function(e) {
	                        menuOverlay.hide('fast', function(e) {
	                            setCookie('menuOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
	                        });
		                	safariOverlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
				                safariOverlay.hide('fast');
				            });
	                    });
	                }

		            menuOverlay.on('click', '.daftplugPublicMenuOverlay_dismiss', function(e) {
		                menuOverlay.hide('fast', function(e) {
		                    setCookie('menuOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                });
		            });
		        }

		        // Handle checkout installation overlay
		        if (objectName.settings.pwaOverlaysTypes.includes('checkout') && isAndroidStandalone == false && isIosStandalone == false && isCheckoutOverlayShown == null && checkoutOverlay.length) {
	                if (objectName.settings.pwaOverlaysBrowsers.includes('chrome') && isAndroidChrome && chrome2Overlay.length) {
			            navigator.serviceWorker.getRegistrations().then(registrations => {
			                if (!registrations.length == 0) {
			                    var installPromptEvent = void 0;
			                    window.addEventListener('beforeinstallprompt', function(event) {
			                        event.preventDefault();
			                        installPromptEvent = event;
			                        checkoutOverlay.css('display', 'flex').on('click', '.daftplugPublicCheckoutOverlay_install', function(e) {
			                            checkoutOverlay.hide('fast', function(e) {
			                                setCookie('checkoutOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
			                            });

			                            installPromptEvent.prompt();
			                            installPromptEvent.userChoice.then(function(choice) {
			                                if (choice.outcome === 'accepted') {
			                                    // User accepted the A2HS prompt
			                                } else {
			                                    checkoutOverlay.css('display', 'flex');
			                                }
			                                installPromptEvent = null;
			                            });
			                        });
			                    });
			                } else {
					            checkoutOverlay.css('display', 'flex').on('click', '.daftplugPublicCheckoutOverlay_install', function(e) {
		                            checkoutOverlay.hide('fast', function(e) {
		                                setCookie('checkoutOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                            });
				                	chrome2Overlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
						                chrome2Overlay.hide('fast');
						            });
			                    });
			                }
			            });
	                } else if (objectName.settings.pwaOverlaysBrowsers.includes('firefox') && isAndroidFirefox && firefoxOverlay.length) {
					    checkoutOverlay.css('display', 'flex').on('click', '.daftplugPublicCheckoutOverlay_install', function(e) {
	                        checkoutOverlay.hide('fast', function(e) {
	                            setCookie('checkoutOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
	                        });
		                	firefoxOverlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
				                firefoxOverlay.hide('fast');
				            });
	                    });
	                } else if (objectName.settings.pwaOverlaysBrowsers.includes('safari') && isIosSafari && safariOverlay.length) {
						checkoutOverlay.css('display', 'flex').on('click', '.daftplugPublicCheckoutOverlay_install', function(e) {
	                        checkoutOverlay.hide('fast', function(e) {
	                            setCookie('checkoutOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
	                        });
		                	safariOverlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
				                safariOverlay.hide('fast');
				            });
	                    });
	                }

		            checkoutOverlay.on('click', '.daftplugPublicCheckoutOverlay_dismiss', function(e) {
		                checkoutOverlay.hide('fast', function(e) {
		                    setCookie('checkoutOverlay', 'shown', objectName.settings.pwaOverlaysShowAgain);
		                });
		            });
		        }

	            // Handle installation button
	            if (isAndroidStandalone == false && isIosStandalone == false && installButton.length) {
	                if (objectName.settings.pwaOverlaysBrowsers.includes('chrome') && isAndroidChrome && chrome2Overlay.length) {
	                    navigator.serviceWorker.getRegistrations().then(registrations => {
	                        if (!registrations.length == 0) {
	                            var installPromptEvent = void 0;
	                            window.addEventListener('beforeinstallprompt', function(event) {
	                                event.preventDefault();
	                                installPromptEvent = event;
	                                installButton.on('click', function(e) {
	                                    installPromptEvent.prompt();
	                                    installPromptEvent.userChoice.then(function(choice) {
	                                        if (choice.outcome === 'accepted') {
	                                            // User accepted the A2HS prompt
	                                        } else {
	                                            // User dismissed the A2HS prompt
	                                        }
	                                        installPromptEvent = null;
	                                    });
	                                });
	                            });
	                        } else {
	                            installButton.on('click', function(e) {
	                                chrome2Overlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
	                                    chrome2Overlay.hide('fast');
	                                });
	                            });
	                        }
	                    });
	                } else if (objectName.settings.pwaOverlaysBrowsers.includes('firefox') && isAndroidFirefox && firefoxOverlay.length) {
	                    installButton.on('click', function(e) {
	                        firefoxOverlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
	                            firefoxOverlay.hide('fast');
	                        });
	                    });
	                } else if (objectName.settings.pwaOverlaysBrowsers.includes('safari') && isIosSafari && safariOverlay.length) {
	                    installButton.on('click', function(e) {
	                        safariOverlay.show().on('click', '.daftplugPublicOverlay_close', function(e) {
	                            safariOverlay.hide('fast');
	                        });
	                    });
	                }
	            }
	        }

	        // Handle iOS standalone stuff
	        if (isIosStandalone) {
	            //Stop link clicks out of the iOS standalone
	            var noddy, remotes = false;
	            document.addEventListener('click', function(event) {
	                noddy = event.target;
	                if (noddy.tagName.toLowerCase() !== 'a' || noddy.hostname !== window.location.hostname || noddy.pathname !== window.location.pathname || !/#/.test(noddy.href)) return;

	                while (noddy.nodeName !== 'A' && noddy.nodeName !== 'HTML') {
	                    noddy = noddy.parentNode;
	                }

	                if ('href' in noddy && noddy.href.indexOf('http') !== -1 && (noddy.href.indexOf(document.location.host) !== -1 || remotes)) {
	                    event.preventDefault();
	                    document.location.href = noddy.href;
	                }
	            }, false);

	            // Display rotate device notice based on orientation
	            setInterval(function() {
	                if ((objectName.settings.pwaOrientation == 'portrait' && window.matchMedia('(orientation: landscape)').matches) || (objectName.settings.pwaOrientation == 'landscape' && window.matchMedia('(orientation: portrait)').matches)) {
	                    daftplugPublic.find('.daftplugPublicRotateNotice').css('display', 'flex');
	                    window.onorientationchange = function(e) {
	                        daftplugPublic.find('.daftplugPublicRotateNotice').hide();
	                    };
	                }
	            }, 100);
	        }

	        // Handle both standalone stuff
	        if (isAndroidStandalone || isIosStandalone) {
	            if (jQuery('form').length) {
	                jQuery('form').attr('data-persist', 'garlic');
	            }
	        }
        }

        // Handle PWA installation analytics
        window.onappinstalled = function(e) { 
            jQuery.ajax({
                url: objectName.ajaxUrl,
                dataType: 'text',
                type: 'POST',
                data: {
                    action: optionName + '_save_installation_analytics',
                },
                beforeSend: function() {
                    console.log('saving');
                },
                success: function(response, textStatus, jqXhr) {
                    console.log('saved');
                },
                complete: function() {

                },
                error: function(jqXhr, textStatus, errorThrown) {
                    console.log(jqXhr);
                }
            }); 
        };
    });
})(jQuery);