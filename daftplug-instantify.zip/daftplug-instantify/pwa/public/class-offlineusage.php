<?php

if (!defined('ABSPATH')) exit;

if (!class_exists('daftplugInstantifyPwaPublicOfflineusage')) {
    class daftplugInstantifyPwaPublicOfflineusage {
        public $name;
        public $description;
        public $slug;
        public $version;
        public $textDomain;
        public $optionName;

        public $pluginFile;
        public $pluginBasename;

        public $settings;

        public $daftplugInstantifyPwaPublic;

        public function __construct($config, $daftplugInstantifyPwaPublic) {
            $this->name = $config['name'];
            $this->description = $config['description'];
            $this->slug = $config['slug'];
            $this->version = $config['version'];
            $this->textDomain = $config['text_domain'];
            $this->optionName = $config['option_name'];

            $this->pluginFile = $config['plugin_file'];
            $this->pluginBasename = $config['plugin_basename'];

            $this->settings = $config['settings'];

            $this->daftplugInstantifyPwaPublic = $daftplugInstantifyPwaPublic;

            add_action('parse_request', array($this, 'generateServiceWorker'));
            add_filter('query_vars', array($this, 'addServiceWorkerQueryVar'));
            add_action('wp_head', array($this, 'renderRegisterServiceWorker'));
        }

        public function generateServiceWorker() {
            if (isset($GLOBALS['wp']->query_vars['daftplugInstantifyPwaServiceWorker'])) {
                if (1 == $GLOBALS['wp']->query_vars['daftplugInstantifyPwaServiceWorker']) {
                    header('Content-Type: text/javascript; charset=utf-8');
                    $siteUrl = $this->getPwaRegisterUrl(trailingslashit(get_site_url()));
                    $offlinePage = $this->getPwaRegisterUrl(daftplugInstantify::getSetting('pwaOfflinePage'));
                    $cachedPages = array();
                    $cachedPages[] = "'$siteUrl'";
                    $offlineUrls = daftplugInstantify::getSetting('pwaOfflineContent');

                    if (is_array($offlineUrls)) {
                        foreach ($offlineUrls as $offlineUrl) {
                            $offlineUrl = $this->getPwaRegisterUrl($offlineUrl);
                            $cachedPages[] = "'$offlineUrl'";
                        }
                    }

                    $serviceWorkerData = array(
                        'cacheName' => $this->optionName,
                        'offlinePage' => $offlinePage,
                        'cachedPages' => '['.implode(',', $cachedPages).']',
                    );

                    $serviceWorker = file_get_contents(plugins_url('pwa/public/assets/js/script-serviceworker.js', $this->pluginFile));
                    $serviceWorker = apply_filters("{$this->optionName}_pwa_serviceworker", $serviceWorker);

                    foreach ($serviceWorkerData as $key => $val) {
                        $serviceWorker = str_replace("{{{$key}}}", $val, $serviceWorker);
                    }

                    echo $serviceWorker;
                    exit;
                }
            }
        }

        public function addServiceWorkerQueryVar($queryVars) {
            $queryVars[] = 'daftplugInstantifyPwaServiceWorker';

            return $queryVars;
        }

        public function renderRegisterServiceWorker() {
            include_once($this->daftplugInstantifyPwaPublic->partials['registerServiceWorker']);
        }

        public static function getServiceWorkerUrl($encoded = true) {
            $url = add_query_arg(array('daftplugInstantifyPwaServiceWorker' => 1), site_url('/', 'https'));
            if ($encoded) {
                return wp_json_encode($url);
            }

            return $url;
        }

        public function getPwaRegisterUrl($url) {
            $siteUrl = untrailingslashit(get_site_url());
            $urlParts = parse_url($siteUrl);
            $baseUrl = $urlParts['scheme'].'://'.$urlParts['host'];

            if (strpos($url, $siteUrl) != 0) {
                return '';
            }

            return str_replace($baseUrl, '', $url);
        }
    }
}