<?php

if (!defined('ABSPATH')) exit;

if (!class_exists('daftplugInstantifyPwaPublicPushnotifications')) {
    class daftplugInstantifyPwaPublicPushnotifications {
    	public $name;
        public $description;
        public $slug;
        public $version;
        public $textDomain;
        public $optionName;

        public $pluginFile;
        public $pluginBasename;

        public $settings;
        public $firebaseCreds;
        public $subscribedDevices;

        public $daftplugInstantifyPwaPublic;

    	public function __construct($config, $daftplugInstantifyPwaPublic) {
    		$this->name = $config['name'];
            $this->description = $config['description'];
            $this->slug = $config['slug'];
            $this->version = $config['version'];
            $this->textDomain = $config['text_domain'];
            $this->optionName = $config['option_name'];

            $this->pluginFile = $config['plugin_file'];
            $this->pluginBasename = $config['plugin_basename'];

            $this->settings = $config['settings'];
            $this->firebaseCreds = get_option("{$this->optionName}_firebase_creds", true);
            $this->subscribedDevices = get_option("{$this->optionName}_subscribed_devices", true);

            $this->daftplugInstantifyPwaPublic = $daftplugInstantifyPwaPublic;

            if ($this->firebaseCreds['pwaPush'] == 'on') {
                add_filter("{$this->optionName}_pwa_manifest", array($this, 'addSenderIdToManifest'));
                add_filter("{$this->optionName}_pwa_serviceworker", array($this, 'addPushToServiceWorker'));
                add_action("wp_ajax_{$this->optionName}_handle_subscription_id", array($this, 'handleSubscriptionId'));
                add_action("wp_ajax_nopriv_{$this->optionName}_handle_subscription_id", array($this, 'handleSubscriptionId'));

                if (daftplugInstantify::getSetting('pwaSubscribeButton') == 'on') {
                    add_filter("{$this->optionName}_public_html", array($this, 'renderSubscribeButton'));
                }
            }
    	}

        public function addSenderIdToManifest($manifest) {
            $manifest['gcm_sender_id'] = "{$this->firebaseCreds['pwaSenderId']}";

            return $manifest;
        }

        public function addPushToServiceWorker($serviceWorker) {
            $serviceWorker .= file_get_contents(plugins_url('pwa/public/assets/js/script-push.js', $this->pluginFile));

            return $serviceWorker;
        }

        public function handleSubscriptionId() {
            if (!isset($_POST['subscriptionId']) || !isset($_POST['handle']) || $_POST['subscriptionId'] == '' || !in_array($_POST['handle'], array('add', 'remove'))) {
                wp_die('0');
            }

            $subscriptionId = $_POST['subscriptionId'];
            $handle = $_POST['handle'];
            $subscribedDevices = $this->subscribedDevices;

            if ($handle =='add') {
                $subscribedDevices[$subscriptionId] = array(
                    'deviceInfo' => $_POST['deviceInfo'],
                    'time' => date('j M Y'),
                    'subscriptionId' => $subscriptionId,
                );
            } elseif ($handle == 'remove') {
                unset($subscribedDevices[$subscriptionId]);
            }

            $handled = update_option("{$this->optionName}_subscribed_devices", $subscribedDevices);

            if ($handled) {
                wp_die('1');
            } else {
                wp_die('0');
            }
        }

        public function renderSubscribeButton() {
            if (function_exists('is_amp_endpoint') && is_amp_endpoint()) {
                return;
            }
            
            include_once($this->daftplugInstantifyPwaPublic->partials['subscribeButton']);
        }
    }
}