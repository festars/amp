<?php

if (!defined('ABSPATH')) exit;

$siteUrlParts = parse_url(trailingslashit(get_site_url()));
$path = '/';

if (array_key_exists('path', $siteUrlParts)) {
    $path = $siteUrlParts['path'];
}

if (function_exists('is_amp_endpoint') && is_amp_endpoint()) {
	?>
	<amp-install-serviceworker
	      src="<?php echo $this->getServiceWorkerUrl(false); ?>"
	      data-scope="<?php echo $path; ?>"
	      layout="nodisplay">
	</amp-install-serviceworker>
	<?php
} else {
	?>
	<script type="text/javascript" id="serviceworker">
	    if (navigator.serviceWorker) {
	        window.addEventListener('load', function() {
	            navigator.serviceWorker.register(
	                <?php echo $this->getServiceWorkerUrl(); ?>, {scope: "<?php echo str_replace('/', '\/', $path); ?>"}
	            );
	        });
	    }
	</script>
	<?php
}

?>