<?php

if (!defined('ABSPATH')) exit;

$appName = daftplugInstantify::getSetting('pwaName');
$appIcon = (has_site_icon()) ? get_site_icon_url(150) : wp_get_attachment_image_src(daftplugInstantify::getSetting('pwaIcon'), array(150, 150))[0];
$cib = esc_html__('Continue in browser', $this->textDomain);
$tit = esc_html__('To install tap', $this->textDomain);
$ac = esc_html__('and choose', $this->textDomain);
$aths = esc_html__('Add to Home Screen', $this->textDomain);

if (in_array('chrome', (array)daftplugInstantify::getSetting('pwaOverlaysBrowsers'))) {
	?>
	<div class="daftplugPublicOverlay -chrome">
	    <div class="daftplugPublicOverlay_close"><?php echo $cib; ?></div>
	    <div class="daftplugPublicOverlay_logo" style="background-image:url(<?php echo $appIcon; ?>)"><?php echo $appName; ?></div>
	    <div class="daftplugPublicOverlay_text"><?php echo $tit.' '.$aths; ?></div>
	    <div class="daftplugPublicOverlay_icon -pointer"></div>
	    <div class="daftplugPublicOverlay_button"><?php echo $aths; ?></div>
	</div>

    <div class="daftplugPublicOverlay -chrome2">
        <div class="daftplugPublicOverlay_icon -pointer"></div>
        <div class="daftplugPublicOverlay_logo" style="background-image:url(<?php echo $appIcon; ?>)"><?php echo $appName; ?></div>
        <div class="daftplugPublicOverlay_text">
        	<?php echo $tit; ?>
        	<div class="daftplugPublicOverlay_icon -home"></div>
        	<?php echo $ac; ?><br>
        	<?php echo $aths; ?>
        </div>
        <div class="daftplugPublicOverlay_close"><?php echo $cib; ?></div>
    </div>
	<?php 
}

if (in_array('firefox', (array)daftplugInstantify::getSetting('pwaOverlaysBrowsers'))) {
	?>
    <div class="daftplugPublicOverlay -firefox">
        <div class="daftplugPublicOverlay_icon -pointer"></div>
        <div class="daftplugPublicOverlay_logo" style="background-image:url(<?php echo $appIcon; ?>)"><?php echo $appName; ?></div>
        <div class="daftplugPublicOverlay_text">
        	<?php echo $tit; ?>
        	<div class="daftplugPublicOverlay_icon -home"></div>
        	<?php echo $ac; ?><br>
        	<?php echo $aths; ?>
        </div>
        <div class="daftplugPublicOverlay_close"><?php echo $cib; ?></div>
    </div>
	<?php 
}

if (in_array('safari', (array)daftplugInstantify::getSetting('pwaOverlaysBrowsers'))) {
	?>
	<div class="daftplugPublicOverlay -safari">
        <div class="daftplugPublicOverlay_close"><?php echo $cib; ?></div>
        <div class="daftplugPublicOverlay_logo" style="background-image:url(<?php echo $appIcon; ?>)"><?php echo $appName; ?></div>
        <div class="daftplugPublicOverlay_text">
        	<?php echo $tit; ?>
        	<div class="daftplugPublicOverlay_icon -home"></div>
        	<?php echo $ac; ?><br>
        	<?php echo $aths; ?>   
        </div>
        <div class="daftplugPublicOverlay_icon -pointer"></div>
    </div>
	<?php
}

?>