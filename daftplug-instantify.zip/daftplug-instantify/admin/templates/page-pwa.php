<?php

if (!defined('ABSPATH')) exit;

?>
<article class="daftplugAdminPage -pwa" data-page="pwa">
    <div class="daftplugAdminPage_heading -flex12">
    	<img class="daftplugAdminPage_illustration" src="<?php echo plugins_url('admin/assets/img/illustration-pwa.png', $this->pluginFile)?>"/>
        <h2 class="daftplugAdminPage_title"><?php esc_html_e('Progressive Web Apps', $this->textDomain); ?></h2>
        <h5 class="daftplugAdminPage_subheading"><?php esc_html_e('Progressive Web Apps use modern web capabilities to deliver fast, native-app experiences with no app stores or downloads, and all the goodness of the web.', $this->textDomain); ?></h5>
    </div>
    <?php $this->daftplugInstantifyPwa->daftplugInstantifyPwaAdmin->getPage(); ?>
</article>