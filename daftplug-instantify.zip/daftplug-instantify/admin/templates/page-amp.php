<?php

if (!defined('ABSPATH')) exit;

?>
<article class="daftplugAdminPage -amp" data-page="amp">
    <div class="daftplugAdminPage_heading -flex12">
    	<img class="daftplugAdminPage_illustration" src="<?php echo plugins_url('admin/assets/img/illustration-amp.png', $this->pluginFile)?>"/>
        <h2 class="daftplugAdminPage_title"><?php esc_html_e('Google AMP', $this->textDomain); ?></h2>
        <h5 class="daftplugAdminPage_subheading"><?php esc_html_e('AMP provides a straightforward way to create web pages that are fast, smooth-loading and prioritize the user-experience above all else.', $this->textDomain); ?></h5>
    </div>
    <?php 
    if (!$this->daftplugInstantifyAmp->isAmpPluginActive()) {
    	$this->daftplugInstantifyAmp->daftplugInstantifyAmpAdmin->getPage();
    } else {
    ?>
    <div class="daftplugAdminPage_content -flex8">
        <fieldset class="daftplugAdminFieldset">
            <h4 class="daftplugAdminFieldset_title">AMP Plugin Detected</h4>
            <p class="daftplugAdminFieldset_description"><?php esc_html_e('You are using a third-party AMP plugin, so this section and AMP features are not active. Please disable all other AMP plugins and visit this section again to enable AMP pages on your website.', $this->textDomain); ?></p>
        </fieldset>
    </div>
	<?php
    }
    ?>
</article>