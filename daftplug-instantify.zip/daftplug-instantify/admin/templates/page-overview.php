<?php

if (!defined('ABSPATH')) exit;

?>
<article class="daftplugAdminPage -overview" data-page="overview">
    <div class="daftplugAdminPage_heading -flex12">
        <img class="daftplugAdminPage_illustration" src="<?php echo plugins_url('admin/assets/img/illustration-overview.png', $this->pluginFile)?>"/>
        <h2 class="daftplugAdminPage_title"><?php esc_html_e('Overview', $this->textDomain); ?></h2>
        <h5 class="daftplugAdminPage_subheading"><?php printf(__('Welcome to <strong>%s</strong> plugin. Here you may find status, analytics, warnings or any other information related to the plugin.', $this->textDomain), $this->name); ?></h5>
    </div>
	<?php $this->renderNotice(); ?>
    <div class="daftplugAdminPage_content -flex5">
        <div class="daftplugAdminContentWrapper">
            <div class="daftplugAdminStatus -flexAuto">
    		    <h4 class="daftplugAdminStatus_title">Overall Status</h4>
                <?php
                $overallStatus = $this->getOverallStatus();
                foreach ($overallStatus as $overall => $status) {
                ?>
                <div class="daftplugAdminStatus_container">
                    <div class="daftplugAdminStatus_label -flex4"><?php echo $status['title'] ?></div>
                    <?php
                    if ($status['condition']) {
                        echo '<div class="daftplugAdminStatus_text -flexAuto"><svg class="daftplugAdminStatus_icon -iconCheck"><use href="#iconCheck"></use></svg> '.$status['true'].'</div>';
                    } else {
                        echo '<div class="daftplugAdminStatus_text -flexAuto"><svg class="daftplugAdminStatus_icon -iconX"><use href="#iconX"></use></svg> '.$status['false'].'</div>';
                    }
                    ?>
                </div>
                <?php
                }
                ?>
            </div>
    	</div>
    </div>
    <div class="daftplugAdminPage_content -flex7">
        <div class="daftplugAdminContentWrapper">
            <div class="daftplugAdminInstallationAnalytics -flexAuto">
                <h4 class="daftplugAdminInstallationAnalytics_title"><?php esc_html_e('PWA Installation Analytics', $this->textDomain); ?></h4>
                <div class="daftplugAdminInstallationAnalytics_chartArea">
                    <canvas id="daftplugAdminInstallationAnalytics_chart"></canvas>
                </div>
            </div>    
    	</div>
    </div>
    <div class="daftplugAdminPage_content -flex5">
        <div class="daftplugAdminContentWrapper">
            <div class="daftplugAdminAmpInfo -flexAuto <?php if (daftplugInstantifyAmp::isAmpPluginActive()) { echo '-disabled'; } ?>">
                <h4 class="daftplugAdminFbiaInfo_title"><?php esc_html_e('Google AMP', $this->textDomain); ?></h4>
                <div class="daftplugAdminStatus_container">
                    <div class="daftplugAdminStatus_label -flex4"><?php esc_html_e('AMP URL', $this->textDomain); ?></div>
                    <div class="daftplugAdminStatus_text -flex8"><a class="daftplugAdminLink" href="<?php echo site_url().'/?amp'; ?>" target="_blank"><?php echo site_url().'/?amp'; ?></a></div>                
                </div>
                <div class="daftplugAdminStatus_container">
                    <div class="daftplugAdminStatus_label -flex4"><?php esc_html_e('Mode', $this->textDomain); ?></div>
                    <div class="daftplugAdminStatus_text -flex8"><?php printf(esc_html__('%s', $this->textDomain), ucfirst(daftplugInstantify::getSetting('ampMode'))); ?></div>                
                </div>
                <div class="daftplugAdminStatus_container">
                    <div class="daftplugAdminStatus_label -flex4"><?php esc_html_e('Design', $this->textDomain); ?></div>
                    <div class="daftplugAdminStatus_text -flex8"><?php esc_html_e('Using current theme styles', $this->textDomain); ?></div>               
                </div>
            </div>    
        </div>
    </div>
    <div class="daftplugAdminPage_content -flex7">
        <div class="daftplugAdminContentWrapper">
            <div class="daftplugAdminFbiaInfo -flexAuto">
                <h4 class="daftplugAdminFbiaInfo_title"><?php esc_html_e('Facebook Instant Articles', $this->textDomain); ?></h4>
                <div class="daftplugAdminStatus_container">
                    <div class="daftplugAdminStatus_label -flex4"><?php esc_html_e('RSS Feed URL', $this->textDomain); ?></div>
                    <div class="daftplugAdminStatus_text -flex8"><a class="daftplugAdminLink" href="<?php echo $this->daftplugInstantifyFbia->feedUrl; ?>" target="_blank"><?php echo $this->daftplugInstantifyFbia->feedUrl; ?></a></div>                
                </div>
                <div class="daftplugAdminStatus_container">
                    <div class="daftplugAdminStatus_label -flex4"><?php esc_html_e('Articles', $this->textDomain); ?></div>
                    <div class="daftplugAdminStatus_text -flex8"><?php echo $this->daftplugInstantifyFbia->getArticleCount(); ?></div>                
                </div>
                <div class="daftplugAdminStatus_container">
                    <div class="daftplugAdminStatus_label -flex4"><?php esc_html_e('Audience Network', $this->textDomain); ?></div>
                    <div class="daftplugAdminStatus_text -flex8"><?php echo (daftplugInstantify::getSetting('fbiaAudienceNetwork') == 'on' ? esc_html__('ON', $this->textDomain) : esc_html__('OFF', $this->textDomain)); ?></div>               
                </div>
            </div>    
        </div>
    </div>
</article>