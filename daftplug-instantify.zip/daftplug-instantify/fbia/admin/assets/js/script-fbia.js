(function($) {
'use strict';
    jQuery(function() {
    	var daftplugAdmin = jQuery('.daftplugAdmin');
    	var optionName = daftplugAdmin.attr('data-daftplug-plugin');
    	var objectName = window[optionName + '_admin_js_vars'];
    	
    });
})(jQuery);