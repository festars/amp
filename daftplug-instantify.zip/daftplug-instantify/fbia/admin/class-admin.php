<?php

if (!defined('ABSPATH')) exit;

if (!class_exists('daftplugInstantifyFbiaAdmin')) {
    class daftplugInstantifyFbiaAdmin {
    	public $name;
        public $description;
        public $slug;
        public $version;
        public $textDomain;
        public $optionName;

        public $pluginFile;
        public $pluginBasename;

        public $settings;

        public $pages;

        public $daftplugInstantifyFbiaAdminGeneral;
        public $daftplugInstantifyFbiaAdminAdvertisements;
        public $daftplugInstantifyFbiaAdminAnalytics;

    	public function __construct($config, $daftplugInstantifyFbiaAdminGeneral, $daftplugInstantifyFbiaAdminAdvertisements, $daftplugInstantifyFbiaAdminAnalytics) {
    		$this->name = $config['name'];
            $this->description = $config['description'];
            $this->slug = $config['slug'];
            $this->version = $config['version'];
            $this->textDomain = $config['text_domain'];
            $this->optionName = $config['option_name'];

            $this->pluginFile = $config['plugin_file'];
            $this->pluginBasename = $config['plugin_basename'];

            $this->settings = $config['settings'];

            $this->pages = $this->generatePages();

            $this->daftplugInstantifyFbiaAdminGeneral = $daftplugInstantifyFbiaAdminGeneral;
            $this->daftplugInstantifyFbiaAdminAdvertisements = $daftplugInstantifyFbiaAdminAdvertisements;
            $this->daftplugInstantifyFbiaAdminAnalytics = $daftplugInstantifyFbiaAdminAnalytics;

            add_action('admin_enqueue_scripts', array($this, 'loadAssets'));
            update_option('posts_per_rss', '30');
    	}

        public function loadAssets() {
            wp_enqueue_style("{$this->slug}-fbia-admin", plugins_url('fbia/admin/assets/css/style-fbia.css', $this->pluginFile), array(), $this->version);
            wp_enqueue_script("{$this->slug}-fbia-admin", plugins_url('fbia/admin/assets/js/script-fbia.js', $this->pluginFile), array('jquery'), $this->version, true);
        }

        public function generatePages() {
            $pages = array(
                array(
                    'id' => 'general',
                    'title' => esc_html__('General', $this->textDomain),
                    'template' => plugin_dir_path(__FILE__) . implode(DIRECTORY_SEPARATOR, array('templates', 'page-general.php'))
                ),
                array(
                    'id' => 'advertisements',
                    'title' => esc_html__('Advertisements', $this->textDomain),
                    'template' => plugin_dir_path(__FILE__) . implode(DIRECTORY_SEPARATOR, array('templates', 'page-advertisements.php')),
                ),
                array(
                    'id' => 'analytics',
                    'title' => esc_html__('Analytics', $this->textDomain),
                    'template' => plugin_dir_path(__FILE__) . implode(DIRECTORY_SEPARATOR, array('templates', 'page-analytics.php'))
                )
            );

            return $pages;
        }

        public function getPage() {
            ?>
            <div class="daftplugAdminSubmenu">
                <ul class="daftplugAdminSubmenu_list">
                <?php
                foreach ($this->pages as $page) {
                    ?>
                    <li class="daftplugAdminSubmenu_item -<?php esc_html_e($page['id']); ?>">
                        <a class="daftplugAdminSubmenu_link" href="#/fbia-<?php esc_html_e($page['id']); ?>/" data-subpage="<?php esc_html_e($page['id']); ?>">
                            <?php esc_html_e($page['title']); ?>
                        </a>
                    </li>
                    <?php
                }
                ?>
                </ul>
            </div>
            <?php
            foreach ($this->pages as $page) {
                include_once($page['template']);
            }
        }
    }
}