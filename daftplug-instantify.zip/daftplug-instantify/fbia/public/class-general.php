<?php

if (!defined('ABSPATH')) exit;

if (!class_exists('daftplugInstantifyFbiaPublicGeneral')) {
    class daftplugInstantifyFbiaPublicGeneral {
    	public $name;
        public $description;
        public $slug;
        public $version;
        public $textDomain;
        public $optionName;

        public $pluginFile;
        public $pluginBasename;

        public $settings;

        public $daftplugInstantifyFbiaPublic;

    	public function __construct($config, $daftplugInstantifyFbiaPublic) {
    		$this->name = $config['name'];
            $this->description = $config['description'];
            $this->slug = $config['slug'];
            $this->version = $config['version'];
            $this->textDomain = $config['text_domain'];
            $this->optionName = $config['option_name'];

            $this->pluginFile = $config['plugin_file'];
            $this->pluginBasename = $config['plugin_basename'];

            $this->settings = $config['settings'];

            add_action('wp_head', array($this, 'addFbPageMetaTag'));
            add_action('init', array($this, 'registerTaxonomy'));
            add_action('pre_get_posts', array($this, 'getPostTypeArticles'));
    	}

        public function addFbPageMetaTag() {
            echo '<meta property="fb:pages" content="'.daftplugInstantify::getSetting('fbiaPageId').'"/>';
        }

        public function registerTaxonomy() {
            register_taxonomy(
                "{$this->optionName}_articles",
                (array)daftplugInstantify::getSetting('fbiaPostTypes'),
                array(
                    'hierarchical' => false,
                    'show_ui' => false
                )
            );
        }

        public function getPostTypeArticles($wpQuery) {
            if (($wpQuery->query_vars['feed'] == "{$this->slug}-articles") && $wpQuery->is_main_query()) {
                $exclude[] = 'no';
                $postFormatTaxQuery = array(
                    'taxonomy' => "{$this->optionName}_articles",
                    'field' => 'slug',
                    'terms' => $exclude,
                    'operator' => 'NOT IN'
                );
                $taxQuery = $wpQuery->get('tax_query');

                if (is_array($taxQuery)) {
                    $taxQuery = $taxQuery + $postFormatTaxQuery;
                } else {
                    $taxQuery = array($postFormatTaxQuery);
                }

                $wpQuery->set('tax_query', $taxQuery);
                $wpQuery->set('orderby', 'modified');

                if (!isset($wpQuery->query_vars['post_type'])) {
                    $wpQuery->set('post_type', (array)daftplugInstantify::getSetting('fbiaPostTypes'));
                }
            }

            return $wpQuery;
        }
    }
}