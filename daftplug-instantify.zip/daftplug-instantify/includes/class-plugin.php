<?php

if (!defined('ABSPATH')) exit;

if (!class_exists('daftplugInstantify')) {
    class daftplugInstantify {
        public $name;
        public $description;
        public $slug;
        public $version;
        public $textDomain;
        public $optionName;

        public $pluginFile;
        public $pluginBasename;
        public $pluginUploadDir;

        public $verifyUrl;
        public $itemId;

        public $purchaseCode;

        public $capability;

        public static $settings;

        public $daftplugInstantifyPwa;
        public $daftplugInstantifyAmp;
        public $daftplugInstantifyFbia;
        public $daftplugInstantifyPublic;
        public $daftplugInstantifyAdmin;

        public function __construct($config) {
            $this->name = $config['name'];
            $this->description = $config['description'];
            $this->slug = $config['slug'];
            $this->version = $config['version'];
            $this->textDomain = $config['text_domain'];
            $this->optionName = $config['option_name'];

            $this->pluginFile = $config['plugin_file'];
            $this->pluginBasename = $config['plugin_basename'];
            $this->pluginUploadDir = $config['plugin_upload_dir'];

            $this->verifyUrl = $config['verify_url'];
            $this->itemId = $config['item_id'];

            $this->purchaseCode = 'nullmaster';

            $this->capability = 'manage_options';

            self::$settings = $config['settings'];

            if ($this->purchaseCode) {
	            require_once(plugin_dir_path(dirname(__FILE__)) . 'pwa/includes/class-plugin.php');
	            $this->daftplugInstantifyPwa = new daftplugInstantifyPwa($config);

	            require_once(plugin_dir_path(dirname(__FILE__)) . 'amp/includes/class-plugin.php');
	            $this->daftplugInstantifyAmp = new daftplugInstantifyAmp($config);

	            require_once(plugin_dir_path(dirname(__FILE__)) . 'fbia/includes/class-plugin.php');
	            $this->daftplugInstantifyFbia = new daftplugInstantifyFbia($config);
            }

            if ($this->isPublic()) {
                require_once(plugin_dir_path(dirname(__FILE__)) . 'public/class-public.php');
                $this->daftplugInstantifyPublic = new daftplugInstantifyPublic($config, $this->daftplugInstantifyPwa, $this->daftplugInstantifyAmp, $this->daftplugInstantifyFbia);
            }

            if ($this->isAdmin()) {
                require_once(plugin_dir_path(dirname(__FILE__)) . 'admin/class-admin.php');
                $this->daftplugInstantifyAdmin = new daftplugInstantifyAdmin($config, $this->daftplugInstantifyPwa, $this->daftplugInstantifyAmp, $this->daftplugInstantifyFbia);
            }

            add_action('plugins_loaded', array($this, 'loadTextDomain'));
            add_filter("plugin_action_links_{$this->pluginBasename}", array($this, 'addPluginActionLinks'));
            register_activation_hook($this->pluginFile, array($this, 'onActivate'));
			register_deactivation_hook($this->pluginFile, array($this, 'onDeactivate'));
        }

        public function loadTextDomain() {
            load_plugin_textdomain($this->textDomain, false, dirname($this->pluginBasename) . '/languages/');
        }

        public function addPluginActionLinks($links) {
            $links[] = '<a href="'.esc_url(admin_url("admin.php?page={$this->slug}")).'">Settings</a>';
            $links[] = '<a href="http://codecanyon.net/user/daftplug/portfolio?ref=DaftPlug" target="_blank">More plugins by DaftPlug</a>';
        
            return $links;
        }

        public function onActivate() {
            add_option("{$this->optionName}_settings", array(
                'pwaName' => '',
                'pwaShortName' => '',
                'pwaStartPage' => './',
                'pwaDescription' => '',
                'pwaIcon' => '',
                'pwaDisplayMode' => 'standalone',
                'pwaOrientation' => 'any',
                'pwaIosStatusBarStyle' => 'default',
                'pwaThemeColor' => '',
                'pwaBackgroundColor' => '',
                'pwaOverlays' => 'on',
                'pwaOverlaysBrowsers' => array('chrome', 'firefox', 'safari'),
                'pwaOverlaysTypes' => array('fullscreen'),
                'pwaOverlaysButtonShortcode' => '[pwa-install-button]',
                'pwaOverlaysBackgroundColor' => '#0A10FF',
                'pwaOverlaysTextColor' => '#FFFFFF',
                'pwaOverlaysShowAgain' => '2',
                'pwaOfflinePage' => '',
                'pwaOfflineContent' => '',
                'pwaOfflineNotification' => 'on',
                'pwaOfflineForms' => 'on',
                'pwaPullDownNavigation' => 'off',
                'pwaPullDownNavigationBgColor' => '',
                'pwaToastMessages' => 'on',
                'pwaSwipeNavigation' => 'off', 
                'pwaShakeToRefresh' => 'off', 
                'pwaVibration' => 'off', 
                'pwaPreloader' => 'off', 
                'pwaCssDeliveryOptimization' => 'off', 
                'pwaJsDeliveryOptimization' => 'off', 
                'pwaCacheMinify' => 'off',
                'pwaCompression' => 'off', 
                'pwaCachingHeaders' => 'off',
                'pwaAskOnLoad' => 'off',
                'pwaRemoveIfFail' => 'on', 
                'pwaNotificationBarIcon' => '', 
                'pwaSubscribeButton' => 'on', 
                'pwaBellIconColor' => '#FFFFFF', 
                'pwaButtonBackgroundColor' => '#FF3838', 
                'pwaButtonPosition' => 'bottom-left',
                'ampMode' => 'paired', 
                'ampOnAll' => 'on', 
                'ampOnPages' => '', 
                'ampOnPostTypes' => '', 
                'ampAdSenseAutoAds' => 'off',
                'ampAdSenseAutoAdsClient' => '',
                'ampAdAboveContentSize' => 'responsive',
                'ampAdAboveContentClient' => '',
                'ampAdAboveContentSlot' => '',
                'ampAdInsideContentSize' => 'responsive',
                'ampAdInsideContentClient' => '',
                'ampAdInsideContentSlot' => '',
                'ampAdBelowContentSize' => 'responsive',
                'ampAdBelowContentClient' => '',
                'ampAdBelowContentSlot' => '',
                'ampAdAboveContent' => 'off',
                'ampAdInsideContent' => 'off',
                'ampAdBelowContent' => 'off',
                'ampGoogleAnalytics' => 'off',
                'ampGoogleAnalyticsTrackingId' => '',
                'ampGoogleAnalyticsAmpLinker' => 'off',
                'ampFacebookPixelId' => '',
                'ampSegmentAnalyticsWriteKey' => '',
                'ampStatCounterUrl' => '',
                'ampHistatsAnalyticsId' => '',
                'ampYandexMetrikaCounterId' => '',
                'ampChartbeatAnalyticsAccountId' => '',
                'ampClickyAnalyticsSiteId' => '',
                'ampFacebookPixel' => 'off',
                'ampSegmentAnalytics' => 'off',
                'ampStatCounter' => 'off',
                'ampHistatsAnalytics' => 'off',
                'ampYandexMetrika' => 'off',
                'ampChartbeatAnalytics' => 'off',
                'ampClickyAnalytics' => 'off',
                'ampCookieNotice' => 'off',
                'ampCookieNoticeMessage' => 'This website uses cookies to ensure you get the best experience on our website.',
                'ampCookieNoticeButtonText' => 'Got it!',
                'ampCookieNoticePosition' => 'top',
                'fbiaPageId' => '', 
                'fbiaAudienceNetwork' => 'off', 
                'fbiaAudienceNetworkPlacementId' => '',
                'fbiaAnalytics' => 'off', 
                'fbiaAnalyticsCode' => '', 
                'fbiaPostTypes' => '',
            ));

            add_option("{$this->optionName}_firebase_creds", array(
            	'pwaPush' => '',
            	'pwaServerKey' => '',
            	'pwaSenderId' => '',
            ));

            add_option("{$this->optionName}_subscribed_devices", array());

            set_transient("{$this->optionName}_installation_analytics", array(
                date('j M Y') => 0,
            ));

            if (!is_dir($this->pluginUploadDir)) {
                wp_mkdir_p($this->pluginUploadDir);
            }
        }

        public function onDeactivate() {
            do_action("{$this->optionName}_on_deactivate");
        }

        public static function getSetting($key) {
            if (array_key_exists($key, self::$settings)) {
                return self::$settings[$key];
            } else {
                return false;
            }
        }

        public static function isAdmin() {
            if (function_exists('is_admin') && is_admin()) {
                return true;
            } else {
                $currentUrl = set_url_scheme(
                    sprintf(
                        'http://%s%s',
                        $_SERVER['HTTP_HOST'],
                        $_SERVER['REQUEST_URI']
                    )
                );
                $adminUrl = strtolower(admin_url());

                if (strpos($currentUrl, $adminUrl) !== false) {
                    return true;
                } else {
                    return false;
                }
            }
        }

        public static function isPublic() {
            if (function_exists('is_admin') && function_exists('wp_doing_ajax') && !is_admin() && wp_doing_ajax()) {
                return true;
            } else {
                $currentUrl = set_url_scheme(
                    sprintf(
                        'http://%s%s',
                        $_SERVER['HTTP_HOST'],
                        $_SERVER['REQUEST_URI']
                    )
                );
                $adminUrl = strtolower(admin_url());

                if (strpos($currentUrl, $adminUrl) !== false) {
                    if (strpos($currentUrl, 'admin-ajax.php') !== false) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            }
        }

        public static function isWooCommerceActive() {
            include_once(ABSPATH . 'wp-admin/includes/plugin.php');
            if (is_plugin_active('woocommerce/woocommerce.php')) {
                return true;
            } else {
                return false;
            }
        }
    }
}